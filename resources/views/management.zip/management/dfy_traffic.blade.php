<x-app-layout>
    <div class="">
        <div class="px-10">
            <div>
                <div class="bg-white mt-10  p-5 sm:p-10 text-center w-full lg:w-[80%]  mx-auto space-y-5 text-gray-700">

                    <div class="grid grid-cols-1 lg:grid-cols-5">
                        <div></div>
                        <div class="rounded shadow-md p-5 col-span-3 space-y-5">
                            <p class="font-bold text-xl my-3 tracking-wide">DFY Unlimited Traffic </p>
                            <p class="text-sm font-semibold">Hey there,</p>
                            <p class="text-sm font-semibold">Thank you for your patronage.</p>
                            <p class="text-sm mt-3 font-semibold">To enable you to share our pool of 100% buyer traffic with you, kindly watch this video and revert with your Fb pixel </p>

                            <a href=" https://m.youtube.com/watch?v=jSBKCbIS_sg" target="_blank"
                                class="text-sm text-blue-600 mb-5"> https://m.youtube.com/watch?v=jSBKCbIS_sg</a>
                                <p class="text-sm font-semibold">Thank you..</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>


